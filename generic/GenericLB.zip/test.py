import hashlib
import datetime
import base64
from flask import Flask, url_for,jsonify,abort
from flask import request
from flask import abort
import json
from flask_cors import CORS
import base64
import binascii
import re
import urllib.request
import requests
from threading import Lock, Thread
from apscheduler.schedulers.background import BackgroundScheduler
import time
import os
import subprocess
http_trig = 0
active = 0
lock_counter = Lock()
lock_ports = Lock()
app = Flask(__name__)
CORS(app)


file = open("input.json","r").read()
data = json.loads(file)



print("************** GENERIC LOAD BALANCER **************")
print("Assumptions :")
print("1. You have a docker image of your app created on an AWS instance")
print("2. This load balancer code is to be run on the instance containing the image")
print("3. Ports 8000-8020 are allowed for running the containers")
print("4. Need not have a container already running. If so, \
		the container must be running at port 8000")
print("5. No health check is running.")
print("6. The Generic LB only scales in and scales out based on triggers, and load balances incoming requests" )
print("7. In the input.json file, specify the rules in order.")
print(" For eg. no_of_HTTP_requests must be least in first trigger and most in last trigger")

print("\n\nThe load balancer runs on port 80 of localhost, in the ec2 instance where the microservice is to be load-balanced")

########## Print JSON parameters ###########
#print("Image name : ", data["image_name"])

res = os.popen("sudo docker image ls | grep -i \""+data["image_name"]+"\"").read()
if(not res):
	print("Error in input : Image\"", data["image_name"],"\" not present")
	exit(1)

print("Loaded json data : ", data)
print("\n\nImage \"",data["image_name"],"\" found with tag =", res.split()[1])

#print("Triggers and actions : ")



# For now, the only trigger_name is no_of_HTTP_requests
# Could be increased later

# Load balancer runs on localhost:80
localhost = "http://127.0.0.1:"
image_name = data["image_name"]

ports = [i for i in range(8001, 8020)]

# Active ports, if yes can be specified in input.json file
active_containers = [i for i in data["active_container_ports"]]

if(not len(active_containers)):
	# Start a container at 8000
	active_containers.append(8000)


if(data["trigger_name"]=="no_of_HTTP_requests"):
	counter = 0
	http_trig = 1
else:
	http_trig = 0

def timer2min():
	global active_containers, ports, counter, active, data
	print("TIMER RUNNING - ", time.ctime().split()[3])
	running = len(active_containers)
	print("Total no of requests in the 2 mins : ", counter)
	active = 0

	# Determine how many containers are to be active based on triggers, actions and running containers

	# Check if it's the right trigger
	if(http_trig==1):
		for i in data["triggers_and_actions"]:
			val = i["val"]
			if((i["trigger"]=="<" and (counter<val)) or (i["trigger"]== ">" and (counter>val))):
				print("Trigger id :",str(i["trigger_id"]),"Match.")
				print(i)
				active = i["action"]["quantity"]
				break
		print("Containers running :", active_containers,"(",running,")")
		print("Action corresponding to trigger matched :")
		if(running<active):
			print("Scaling out to",str(active),"containers...")
			add = active-running
			ports_to_run = ports[0:add]
			print("ADDING",add,"CONTAINERS AT PORTS", ports_to_run)
			for i in ports_to_run:
					id = os.popen("sudo docker run -d -p "+str(i)+":80 "+data["image_name"]).read()
					lock_ports.acquire()
					active_containers.append(i)
					ports.remove(i)
					lock_ports.release()
			print("New active containers : ",active_containers)
		elif(running>active):
			print("Scaling in to",str(active),"containers...")
			rem = running-active
			cont = active_containers[-rem:]
			print("REMOVING",rem,"CONTAINERS AT PORTS",cont)
			lock_ports.acquire()
			active_containers = active_containers[:-rem]
			lock_ports.release()
			print("New active containers : ", active_containers)
			for top in cont:
					res = os.popen("sudo docker container ls | grep -i \""+str(top)+"\"").read()
					id = str(res).split()[0]
					os.system("sudo docker stop "+ id)
					os.system("sudo docker rm "+id)
			ports.extend(cont)
		else:
			print("Scaling not required for now...")
	lock_counter.acquire()
	counter = 0
	lock_counter.release()
	print("Resetting counter : ", counter)




# Handle other useless requests
@app.route('/',methods=['POST','GET','DELETE'])
def what_to_do():
		# Do nothing
		return jsonify({"what to do":"nothing"}), 200


# ALL APIS
@app.route(data["minimal_api_path"] + '<path:path>', methods=['POST','GET','DELETE'])
def catch_all(path):
		global counter, active_containers, active, data
		print("active is : ", active)
		if(active==0):
				print("First API request received. Timer started to check for triggers")
				timer = BackgroundScheduler(daemon=True)
				timer.add_job(timer2min,'interval',minutes=data["trigger_interval"])
				timer.start()
		lock_counter.acquire()
		counter+=1
		lock_counter.release()
		active = 1
		lock_ports.acquire()
		portno = active_containers.pop(0)
		active_containers.append(portno)
		lock_ports.release()
		print("Request made to port : ", str(portno),"count=",counter)
		API_ENDPOINT = localhost+str(portno)+data["minimal_api_path"]+path
		if request.method == 'POST':
				#data = request.get_json()
				r = requests.post(url = API_ENDPOINT)
		elif request.method=="GET":
				r = requests.get(url = API_ENDPOINT)
		elif request.method=="DELETE":
				r = requests.delete(url = API_ENDPOINT)
		stat = r.status_code
		if(stat !=204):
				return jsonify(r.json()), r.status_code
		else:
				return jsonify({}), 204


app.run(host="0.0.0.0", port=80)







'''
path = os.getcwd()

syscall = path+"/"+data["private_key"]
awsinstance = data["microservice_username"]+"@"+data["instance_dns"]
result = subprocess.run(['ssh','-i',syscall,awsinstance])

print(result)
result1 = subprocess.run(['ls'])
print(result1)
'''
#dir_path = os.path.dirname(os.path.realpath(__file__))

#print(dir_path)
#print(path)


#res = os.popen(syscall)
#print(res)
#print(data)

